$(function(){
	$(".st>ul>li").click(function(){
		$(this).css({'color':'red','border-bottom':'3px solid red'}).siblings().css({'color':'black','border-bottom':'0px solid red'})
	})
	$(".zhankai1").click(function(){
		$(this).hide()
		$(".shouqi1").show()
		$(this).siblings().children("li:nth-child(n+17)").slideDown()
	})
	$(".shouqi1").click(function(){
		$(this).hide()
		$(".zhankai1").show()
		$(this).siblings().children("li:nth-child(n+17)").slideUp()
	})
	$(".zhankai2").click(function(){
		$(this).hide()
		$(".shouqi2").show()
		$(this).siblings().children("li:nth-child(n+17)").slideDown()
	})
	$(".shouqi2").click(function(){
		$(this).hide()
		$(".zhankai2").show()
		$(this).siblings().children("li:nth-child(n+17)").slideUp()
	})
	$(".s5>div>ul>li>div,.s6>div>ul>li>div").hover(function(){
		$(this).css({"transform": "translateY(-5px)",'transition': 'all 1s',"box-shadow": "0px 0px 15px black"})
	},function(){
		$(this).css({"transform": "translateY(0px)",'transition': 'all 1s',"box-shadow": "0px 0px 0px black"})
	})
	$(".st>ul>li:nth-child(1)").click(function(){
		$(".s5").show();
		$(".s6").hide()
		$(".s7").hide()
	})
	$(".st>ul>li:nth-child(2)").click(function(){
		$(".s5").hide()
		$(".s6").show();
		$(".s7").hide()
	})
	$(".st>ul>li:nth-child(3)").click(function(){
		$(".s5").hide()
		$(".s6").hide();
		$(".s7").show()
	})
	
	
	$(document).on('scroll',function(){
		var src=$(document).scrollTop();
		if(src>=140){
			$('.back').show();
		}else{
			$('.back').hide();
		}
		$('.back').click(function(){
			$(document).scrollTop(0);
		})
	})
})