$(function(){
	$(document).on('scroll',function(){
		var src=$(document).scrollTop();
		if(src>=140){
			$('.back').show();
		}else{
			$('.back').hide();
		}
		$('.back').click(function(){
			$(document).scrollTop(0);
		})
	})
})