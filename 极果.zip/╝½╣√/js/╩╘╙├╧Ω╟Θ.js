$(function(){
	$(".look").toggle(function(){
		$(this).siblings().children("li:nth-child(n+5)").slideDown()
	},function(){
		$(this).siblings().children("li:nth-child(n+5)").slideUp()
	})
	$(document).on('scroll',function(){
		var src=$(document).scrollTop();
		if(src>=140){
			$('.back').show();
		}else{
			$('.back').hide();
		}
		$('.back').click(function(){
			$(document).scrollTop(0);
		})
	})
})