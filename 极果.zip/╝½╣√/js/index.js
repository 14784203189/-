$(function(){
	//json
	var pic=[
		{src:"original (1).jpg"},
		{src:"original (2).jpg"},
		{src:"original(3).jpg"}
	]
	var info=[
		{"num":""},
		{"num":""},
		{"num":""}
	]
	var list='';
	for(var i=0;i<pic.length;i++){
		list+='<li>'+'<img src="img/'+pic[i].src+'"></li>';		
	}
	$(".s1>ul").html(list);
	var num='';
	for(var i=0;i<info.length;i++){
		num+='<li>'+info[i].num+'</li>';
	}
	$(".num>ul").html(num);
	$(".num>ul>li").eq(0).addClass("a");
	var left=$("<span class='left'><</span>");
	var right=$("<span class='right'>></span>");
	$(".s1").append(left);
	$(".s1").append(right);
	var index=0;
	var width=$(".s1>ul>li").width();
	function move(){
		index=index>2?0:index;
		$(".s1>ul>li").eq(index).fadeIn(500).siblings().fadeOut(100)
		$(".num>ul>li").eq(index).addClass("a").siblings().removeClass("a");
	}
	var time=setInterval(function(){
		index++;
		move();
	},3000);
	$(".s1").mouseenter(function(){
		clearInterval(time);
	}).mouseleave(function(){
		time=setInterval(function(){
			index++;
			move();
		},3000);
	})
	$(".num>ul>li").mouseenter(function(){
		index=$(this).index();
		move();
	})
	$(".s1>span").mouseenter(function(){
		$(this).css("background","rgba(000,000,000,0.8)")
	}).mouseleave(function(){
		$(this).css("background","rgba(000,000,000,0.3)")
	})
	$(".s1>.left").click(function(){
		index--;
		index=index<0?2:index;
		move();
	})
	$(".s1>.right").click(function(){
		index++;
		move();
	})
	
	var index1=0;
	var width1=$(".s2>div>ul>li").width();
	function move1(){
		index1=index1>4?0:index1;
		$(".s2>div>ul").stop().animate({left:-width1*index1},500);
	}
	var time1=setInterval(function(){
		index1++;
		move1();
	},3000);
	$(".s2>.left").click(function(){
		index1--;
		index1=index1<0?4:index1;
		move1();
	})
	$(".s2>.right").click(function(){
		index1++;
		move1();
	})
	$(".s3>div>.look").toggle(function(){
		$(this).siblings().children("li:nth-child(n+9)").slideDown()
	},function(){
		$(this).siblings().children("li:nth-child(n+9)").slideUp()
	})
	$(".s4>div>.look").toggle(function(){
		$(this).siblings().children("li:nth-child(n+5)").slideDown()
	},function(){
		$(this).siblings().children("li:nth-child(n+5)").slideUp()
	})
	$(".zhankai").click(function(){
		$(this).hide()
		$(".shouqi").show()
		$(this).siblings().children("li:nth-child(n+17)").slideDown()
	})
	$(".shouqi").click(function(){
		$(this).hide()
		$(".zhankai").show()
		$(this).siblings().children("li:nth-child(n+17)").slideUp()
	})
	$(".s5>div>ul>li>div").hover(function(){
		$(this).css({"transform": "translateY(-5px)",'transition': 'all 1s',"box-shadow": "0px 0px 15px black"})
	},function(){
		$(this).css({"transform": "translateY(0px)",'transition': 'all 1s',"box-shadow": "0px 0px 0px black"})
	})
	
	$(document).on('scroll',function(){
		var src=$(document).scrollTop();
		if(src>=140){
			$('.back').show();
		}else{
			$('.back').hide();
		}
		$('.back').click(function(){
			$(document).scrollTop(0);
		})
	})
	
	
	
})