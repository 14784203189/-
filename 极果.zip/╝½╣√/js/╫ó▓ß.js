$(function(){
	$(".tel").blur(tel);
	$(".name").blur(name);
	$(".psd").blur(psd);
	$(".repsd").blur(repsd);
	$("form").submit(function(){
		var flag=true;
		if(!tel()){
			flag=false;
		}
		if(!name()){
			flag=false;
		}
		if(!checkpwd()){
			flag=false;
		}
		if(!repsd()){
			flag=false;
		}
		return flag;
	})
	function tel(){
		var tel=$(".tel").val()
		var stel=$(".stel");
		stel.html("");
		if(tel==""){
			stel.html("不能为空");
			return false;
		}
		return true;
	}
	function name(){
   		var name=$(".name").val();
   		var sname=$(".sname");
   		sname.html("");
   		if(name==""){
   			sname.html("名字不能为空");
   			return false;
   		}
   		for(var i=0;i<name.length;i++){
   			var j=name.substring(i,i+1);
   			if(isNaN(j)==false){
   				sname.html("名字不能含有数字");
   				return false;
   			}
   		}
   		return true;
   	}
	function psd(){
   		var psd=$(".psd");
   		var spsd=$(".spsd");
   		spsd.html("");
   		if(psd.val()==""){
   			spsd.html("密码不能为空");
   			return false;
   		}
   		if(psd.val().length<6){
   			spsd.html("请输入大于或等于6个的字符");
   			return false;
   		}
   		return true;
   	}
	function repsd(){
   		var psd=$(".psd");
   		var repsd=$(".repsd");
   		var srepsd=$(".srepsd");
   		srepsd.html("");
   		if(psd.val()!=repsd.val()){
   			srepsd.html("两次输入的密码不一致");
   			return false;
   		}
   		return true;
   	}
	
	
	
	
	$(document).on('scroll',function(){
		var src=$(document).scrollTop();
		if(src>=140){
			$('.back').show();
		}else{
			$('.back').hide();
		}
		$('.back').click(function(){
			$(document).scrollTop(0);
		})
	})
})