//赚彩贝hover事件
$(".head-top-left-left").hover(function(){
	$(this).css({"background":"white","color":"orangered"});
	$(this).children("span").css({"border":"5px solid orangered","width":"0px","height":"0px","border-top":"none","border-left-color":"transparent","border-right-color":"transparent"});
	$(this).children("ul").fadeIn(500);
},function(){
	$(this).css({"background":"#545652","color":"#DDDDDD"});
	$(this).children("span").css({"border":"5px solid #DDDDDD","width":"0px","height":"0px","border-bottom":"none","border-left-color":"transparent","border-right-color":"transparent"});
	$(this).children("ul").fadeOut(100);
})
//赚彩贝二级菜单hover事件
$(".head-top-left-left>ul>li").hover(function(){
	$(this).css("background","#DDDDDD");
},function(){
	$(this).css("background","white");
})
//花彩贝hover事件
$(".head-top-left-right").hover(function(){
	$(this).css({"background":"white","color":"orangered"});
	$(this).children("span").css({"border":"5px solid orangered","width":"0px","height":"0px","border-top":"none","border-left-color":"transparent","border-right-color":"transparent"});
	$(this).children("ul").fadeIn(500);
},function(){
	$(this).css({"background":"#545652","color":"#DDDDDD"});
	$(this).children("span").css({"border":"5px solid #DDDDDD","width":"0px","height":"0px","border-bottom":"none","border-left-color":"transparent","border-right-color":"transparent"});
	$(this).children("ul").fadeOut(100);
})
//花彩贝二级菜单hover事件
$(".head-top-left-right>ul>li").hover(function(){
	$(this).css("background","#DDDDDD");
},function(){
	$(this).css("background","white");
})
//搜索框获取焦点时
$(".head-top-right-right>input").focus(function(){
	$(".head-top-right-right-right").hide();
	$(".head-top-right-right-right-1").show();
})
//搜索框失去焦点时
$(".head-top-right-right>input").blur(function(){
	$(".head-top-right-right-right").show();
	$(".head-top-right-right-right-1").hide();
})
//赚积分
$(".nav-in").hover(function(){
	$(".nav-in>span").stop().animate({"width":"0px"},400);
	$(".nav-in>.span-1").stop().animate({"width":"68px"},600);
},function(){
	$(".nav-in>span").stop().animate({"width":"38px"},200);
	$(".nav-in>.span-1").stop().animate({"width":"0px"},300);
})
//返利商城
$(".nav-in-2").hover(function(){
	$(this).css("background-position","-117px -170px")
},function(){
	$(this).css("background-position","-9px -170px")
})
$(".nav-in-4").hover(function(){
	$(this).css("background-position","-117px -255px")
},function(){
	$(this).css("background-position","-9px -255px")
})
//花积分
$(".nav-in-5").hover(function(){
	$(".nav-in-5>span").stop().animate({"width":"0px"},400);
	$(".nav-in-5>.span-1").stop().animate({"width":"68px"},600);
},function(){
	$(".nav-in-5>span").stop().animate({"width":"38px"},200);
	$(".nav-in-5>.span-1").stop().animate({"width":"0px"},300);
})
//积分商城
$(".nav-in-7").hover(function(){
	$(this).css("background-position","-117px -340px")
},function(){
	$(this).css("background-position","-9px -340px")
})
//了解彩贝
$(".nav-in-9").hover(function(){
	$(this).css("background-position","-117px -507px")
	$(this).children().show();
},function(){
	$(this).css("background-position","-9px -507px")
	$(this).children().hide();
})
//彩贝活动
$(".nav-in-11").hover(function(){
	$(this).css("background-position","-117px -424px")
},function(){
	$(this).css("background-position","-9px -424px")
})
//个人中心
$(".nav-in-13").hover(function(){
	$(this).css("background-position","-117px -591px")
},function(){
	$(this).css("background-position","-9px -591px")
})
//精灵图动画
$(".nav-right-0").hover(function(){
	$(".nav-right-1").animate({"margin-top":"-25px"})
	$(".nav-right-4").animate({"margin-top":"-25px"})
},function(){
	$(".nav-right-1").animate({"margin-top":"0px"})
	$(".nav-right-4").animate({"margin-top":"0px"})
})
$(".nav-right-00").hover(function(){
	$(".nav-right-2").animate({"margin-top":"-25px"})
	$(".nav-right-5").animate({"margin-top":"-25px"})
},function(){
	$(".nav-right-2").animate({"margin-top":"0px"})
	$(".nav-right-5").animate({"margin-top":"0px"})
})
$(".nav-right-000").hover(function(){
	$(".nav-right-3").animate({"margin-top":"-25px"})
	$(".nav-right-6").animate({"margin-top":"-25px"})
},function(){
	$(".nav-right-3").animate({"margin-top":"0px"})
	$(".nav-right-6").animate({"margin-top":"0px"})
})
//中间左侧
$(".section-left-bottom-1").hover(function(){
	$(".section-left-bottom-1-right").show();
	$(".section-left-bottom-1>h3").css("color","white");
	$(".section-left-bottom-1>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"","color":""})
	$(".section-left-bottom-1-right").hide();
})

$(".section-left-bottom-1-right-2-1>ul>li").hover(function(e){
		
		var _this  = $(this), //闭包
		_desc  = _this.find(".mask").stop(true),
		width  = _this.width(), //取得元素宽
		height = _this.height(), //取得元素高
		left   = (e.offsetX == undefined) ? getOffset(e).offsetX : e.offsetX, //从鼠标位置，得到左边界，利用修正ff兼容的方法
		top    = (e.offsetY == undefined) ? getOffset(e).offsetY : e.offsetY, //得到上边界
		right  = width - left, //计算出右边界
		bottom = height - top, //计算出下边界
		rect   = {}, //坐标对象，用于执行对应方法。
		_min   = Math.min(left, top, right, bottom), //得到最小值
		_out   = e.type == "mouseleave", //是否是离开事件
		spos   = {}; //起始位置
	
		rect[left] = function (epos){ //鼠从标左侧进入和离开事件
			spos = {"left": -width, "top": 0};
			if(_out){
				_desc.animate(spos, "fast"); //从左侧离开
			}else{
				_desc.css(spos).animate(epos, "fast"); //从左侧进入
			}
		};
	
		rect[top] = function (epos) { //鼠从标上边界进入和离开事件
			spos = {"top": -height, "left": 0};
			if(_out){
				_desc.animate(spos, "fast"); //从上面离开
			}else{
				_desc.css(spos).animate(epos, "fast"); //从上面进入
			}
		};
	
		rect[right] = function (epos){ //鼠从标右侧进入和离开事件
			spos = {"left": left,"top": 0};
			if(_out){
				_desc.animate(spos, "fast"); //从右侧成离开
			}else{
				_desc.css(spos).animate(epos, "fast"); //从右侧进入
			}
		};
	
		rect[bottom] = function (epos){ //鼠从标下边界进入和离开事件
			spos = {"top": height, "left": 0};
			if(_out){
				_desc.animate(spos, "fast"); //从底部离开
			}else{
				_desc.css(spos).animate(epos, "fast"); //从底部进入
			}
		};
	
		rect[_min]({"left":0, "top":0}); // 执行对应边界 进入/离开 的方法
	
	});
	

$(".section-left-bottom-2").hover(function(){
	$(".section-left-bottom-2-right").show();
	$(".section-left-bottom-2>h3").css("color","white");
	$(".section-left-bottom-2>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$(".section-left-bottom-2-right").hide();
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"white","color":""})
})
$(".section-left-bottom-3").hover(function(){
	$(".section-left-bottom-3-right").show();
	$(".section-left-bottom-3>h3").css("color","white");
	$(".section-left-bottom-3>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$(".section-left-bottom-3-right").hide();
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"#F0F0F0","color":""})
})
$(".section-left-bottom-4").hover(function(){
	$(".section-left-bottom-4-right").show();
	$(".section-left-bottom-4>h3").css("color","white");
	$(".section-left-bottom-4>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$(".section-left-bottom-4-right").hide();
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"white","color":""})
})
$(".section-left-bottom-5").hover(function(){
	$(".section-left-bottom-5-right").show();
	$(".section-left-bottom-5>h3").css("color","white");
	$(".section-left-bottom-5>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$(".section-left-bottom-5-right").hide();
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"#F0F0F0","color":""})
})
$(".section-left-bottom-6").hover(function(){
	$(".section-left-bottom-6-right").show();
	$(".section-left-bottom-6>h3").css("color","white");
	$(".section-left-bottom-6>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$(".section-left-bottom-6-right").hide();
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"white","color":""})
})
$(".section-left-bottom-7").hover(function(){
	$(".section-left-bottom-7-right").show();
	$(".section-left-bottom-7>h3").css("color","white");
	$(".section-left-bottom-7>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$(".section-left-bottom-7-right").hide();
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"#F0F0F0","color":""})
})
$(".section-left-bottom-8").hover(function(){
	$(".section-left-bottom-8-right").show();
	$(".section-left-bottom-8>h3").css("color","white");
	$(".section-left-bottom-8>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$(".section-left-bottom-8-right").hide();
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"white","color":""})
})
$(".section-left-bottom-9").hover(function(){
	$(".section-left-bottom-9-right").show();
	$(".section-left-bottom-9>h3").css("color","white");
	$(".section-left-bottom-9>ul>li").css("color","white");
	$(this).css({"background-color":"#464646","color":"white"})
},function(){
	$(".section-left-bottom-9-right").hide();
	$("h3").css("color","");
	$("ul>li").css("color","");
	$(this).css({"background-color":"#F0F0F0","color":""})
})

//轮播图
$(".dian>.dian-1").eq(1).css("opacity","0.5");
var index=0;
function fa(){
	index++;
	index=index>1?0:index;
	$(".section-in-lunbotu").animate({'margin-left':-655*index+"px"});
	$(".dian>.dian-1").eq(index).css("background-color","#D34A18").animate({"height":"40px","opacity":"1","margin-top":"0px","line-height":"40px"},300).siblings().css("background-color","#545652").animate({"height":"30px","opacity":"0.5","margin-top":"10px","line-height":"30px"},300);
}
function time(){
	fa();
}
var time1= setInterval(time,2000);
$(".section-in").hover(function(){
	clearInterval(time1);
},function(){
	time1=setInterval(time,2000);
})
$(".dian-1").hover(function(){
	index=$(this).index();
	$(".section-in-lunbotu").stop().animate({'margin-left':-655*index+"px"});
	$(".dian>.dian-1").eq(index).css("background-color","#D34A18").animate({"height":"40px","opacity":"1","margin-top":"0px","line-height":"40px"},300).siblings().css("background-color","#545652").animate({"height":"30px","opacity":"0.5","margin-top":"10px","line-height":"30px"},100);
})
//右侧高级搜索
$(".section-right-1").hover(function(){
	$(".section-right-1>.xiala").slideDown();
},function(){
	$(".section-right-1>.xiala").slideUp();
})
$(".j-1").hover(function(){
	$(".j-1>a").css("color","orangered");
	$(".j-1>span").css("background-position","0px -114px");
},function(){
	$(".j-1>a").css("color","");
	$(".j-1>span").css("background-position","0px -99px");
})
$(".j-2").hover(function(){
	$(".j-2>a").css("color","orangered");
	$(".j-2>span").css("background-position","-14px -114px");
},function(){
	$(".j-2>a").css("color","");
	$(".j-2>span").css("background-position","-14px -99px");
})
$(".j-3").hover(function(){
	$(".j-3>a").css("color","orangered");
	$(".j-3>span").css("background-position","-29px -114px");
},function(){
	$(".j-3>a").css("color","");
	$(".j-3>span").css("background-position","-29px -99px");
})
$(".j-4").hover(function(){
	$(".j-4>a").css("color","orangered");
	$(".j-4>span").css("background-position","-45px -114px");
},function(){
	$(".j-4>a").css("color","");
	$(".j-4>span").css("background-position","-45px -99px");
})
$(".j-5").hover(function(){
	$(".j-5>a").css("color","orangered");
	$(".j-5>span").css("background-position","-60px -114px");
},function(){
	$(".j-5>a").css("color","");
	$(".j-5>span").css("background-position","-60px -99px");
})
$(".you>span").click(function(){
	$(this).parent().hide();
})

 $('body,html').animate({scrollTop: 0 }, 300);

   var scroHei = $(window).scrollTop();
  if(scroHei==0){
 		$('.xia').hide();
		 }
 $(window).scroll(function() {
        var scroHei = $(window).scrollTop();//滚动的高度
        if (scroHei > 10) {
            $('.you').hide();
            $('.xia').slideDown(300);
        } else {
           $('.you').show();
           $('.xia').hide();
        }
})

 $('.xia-1').click(function() {
        $('body,html').animate({scrollTop: 0 }, 600);
})
 $(".xia-2").hover(function(){
 	$(".xia-2-1").stop().show(300);
 },function(){
 	$(".xia-2-1").stop().hide(300);
 })
  $(".xia-3").hover(function(){
 	$(".xia-3-1").stop().show(300);
 },function(){
 	$(".xia-3-1").stop().hide(300);
 })