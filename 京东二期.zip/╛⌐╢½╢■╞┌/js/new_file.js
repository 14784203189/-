$(function(){
	var index=0;
	var width=$('.pic>ul>li').width();
	console.log(width);
	
	var move=null;
	move=function(){
		index = index > 4 ? 0 : index ;
		$('.pic>ul').stop().animate({left:-width*index},500);
		$('.num>ul>li').eq(index).addClass('active').siblings().removeClass('active');
	}
	var timer=null;
	timer=setInterval(function(){
		index++;	
		move();
	},1000);
	
	
	
	$('.box').hover(function(){
		clearInterval(timer);
	},function(){
		timer=setInterval(function(){
		index++;
		move();
	},1000);
	});
	
	
	$('.num>ul>li').on('mouseenter',function(){
		index=$(this).index();
		move();
	});
	
	$('#left').on('click',function(){
		index--;
		index = index < 0 ? 4 : index ;
		move();
	});
	$('#right').on('click',function(){
		index++;
		move();
	});
	
	
	$('.box').hover(function(){
		$('.jian').show();
	},function(){
		$('.jian').hide();
	})
	
})
